package SocialNetwork;

/**
 * Created by davidaghassi on 9/19/14.
 */
public class Statuses {
    public enum SocialNetworkStatus { SUCCESS, ALREADY_VALID, INVALID_USER, INVALID_DATE, ALREADY_ACTIVE, ALREADY_INACTIVE}
}
